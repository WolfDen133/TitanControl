using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.VisualTree;
using System;
using System.Diagnostics;
using System.Linq;
using TitanControl.Logging;
using TitanControl.ViewModels.Controls.Toolbar;
using TitanControl.Views.Controls.Layout.Grid;
using TitanControl.Views.Controls.Toolbar;
using TitanControl.Views.Controls.Toolbar.Button;
using TitanControl.Views.Controls.Toolbar.Buttons;
using TitanControl.Views.State;

namespace TitanControl.Views.Controls.Toolbar;

public partial class Toolbar : UserControl
{
    public ToolbarModel Model
    {
        get
        {
            if (DataContext is not ToolbarModel m)
                throw new InvalidOperationException($"Could not find valid data context for {nameof(Toolbar)}.");

            return m;
        }
    }

    public Toolbar()
    {
        InitializeComponent();

        EditMode.IsEnabledProperty.Changed.Subscribe(e => Log.Debug($"Edit mode: {e.NewValue.Value}"));
    }

    public void DoResize(int height)
    {
        Height = height;

        InvalidateMeasure();
        InvalidateArrange();
    }

    public int CalculateHeight(int windowWidth)
    {
        float displayMultiplier = Math.Min((float)(windowWidth / 1500f), 1);
        float height = 130f * displayMultiplier;
        height = Math.Min(height, (windowWidth / 2 - Math.Min(138, (windowWidth / 4.85f) / 2) - 30) / Toolstrip.MaxPerPage);

        return (int)height;
    }
}