﻿using CommunityToolkit.Mvvm.ComponentModel;
using System.Drawing;
using System.Threading.Tasks;
using TitanControl.Models;
using TitanControl.Models.Control;
using TitanControl.Services.Session;
using TitanControl.ViewModels.Workspace.Handle.Command;
using TitanControl.Views.Controls.Handle;
using TitanControl.WebAPI.Data;
using HandleInformation = TitanControl.WebAPI.Data.Model.Handle;

namespace TitanControl.ViewModels.Workspace.Handle
{
    public abstract class HandleControlModel<TModel>
        : ObservableObject, IHandleControl<TModel>, ISaveable
        where TModel : ControlModel
    {
        private bool _isSelected;
        private bool _isMoving;
        private HandleInformation? _handleInformation;

        protected ISessionService SessionService;

        protected HandleControlModel(TModel model, ISessionService service)
        {
            Model = model;
            SessionService = service;
        }

        public TModel Model { get; }
        IControlModel IHandleControl.Model => Model;

        protected ICommandMap<TModel> CommandMap { get; set; } = null!;

        public HandleControlId ControlId => Model.ControlId;

        protected HandleInformation? HandleInformation
        {
            get => _handleInformation;
            set
            {
                if (_handleInformation == value)
                    return;

                TitanId = value?.TitanId ?? -1;

                SetProperty(ref _handleInformation, value);
            }

        }
        public bool IsSelected
        {
            get => _isSelected;
            set => SetProperty(ref _isSelected, value);
        }

        public bool IsMoving
        {
            get => _isMoving;
            set => SetProperty(ref _isMoving, value);
        }

        public Rectangle Location
        {
            get => Model.Location;
            set
            {
                if (Model.Location == value)
                    return;

                Model.Location = value;
                OnPropertyChanged(nameof(Location));
            }
        }

        public int TitanId
        {
            get => Model.TitanId;
            private set
            {
                if (Model.TitanId == value)
                    return;

                Model.TitanId = value;
                OnPropertyChanged(nameof(TitanId));
            }
        }

        public HandleType HandleType
        {
            get => Model.HandleType;
            set
            {
                if (Model.HandleType == value)
                    return;

                Model.HandleType = value;
                OnPropertyChanged(nameof(HandleType));
            }
        }

        public HandleKeyProfile KeyProfile
        {
            get => Model.KeyProfile;
            set
            {
                if (Model.KeyProfile == value)
                    return;

                Model.KeyProfile = value;
                OnPropertyChanged(nameof(KeyProfile));
            }
        }

        public Task ExecuteAsync()
        {
            return CommandMap.ExecuteAsync(
                KeyProfile,
                HandleType,
                Model);
        }

        public ISaveModel ToModel()
        {
            return Model;
        }

        public abstract IHandleControl Copy();
    }
}
